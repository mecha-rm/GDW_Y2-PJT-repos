/*
 * Author: Roderick "R.J." Montague (100701758)
 * Date: 09/20/2019
 * Description: includes all files in the Utilities and Tools Project
*/
#ifndef UTILITY_TOOLS_LIBRARY
#define UTILITY_TOOLS_LIBRARY

#include "UtilsLib.h"
#include "math/MathLib.h"

#endif // !UTILITY_TOOLS_LIBRARY

