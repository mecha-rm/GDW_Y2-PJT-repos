/*
 * Name: Roderick "R.J." Montague
 * Student Number: 100701758
 * Date: 03/19/2019
 * References:
*/

// Question 1: MyArray.cpp file
#include "Array.h"
/*
 * Name: Roderick "R.J." Montague
 * Student Number: 100701758
 * Date: 03/23/2019
 * References:
*/

// #include "MyArray.h"

// Question 1: MyArray.cpp.
// There's nothing actually here because template classes cannot be easily split between headers and source files, if at all.