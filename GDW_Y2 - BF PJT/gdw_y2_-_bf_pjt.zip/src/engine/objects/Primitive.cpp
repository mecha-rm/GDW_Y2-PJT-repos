#include "Primitive.h"

Primitive::Primitive() : Object()
{
	
}
