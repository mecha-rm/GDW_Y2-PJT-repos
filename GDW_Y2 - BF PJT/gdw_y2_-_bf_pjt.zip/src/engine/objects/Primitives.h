#pragma once
// Includes all primitives

#include "PrimitiveCube.h"
#include "PrimitiveCylinder.h"
#include "PrimitivePlane.h"
#include "PrimitiveSphere.h"