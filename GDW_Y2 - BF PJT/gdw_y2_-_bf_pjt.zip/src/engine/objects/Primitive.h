// Default Primitives for the Engine
#pragma once

#include "Object.h"

class Primitive : public Object
{
public:
	Primitive();
private:
protected:
};

