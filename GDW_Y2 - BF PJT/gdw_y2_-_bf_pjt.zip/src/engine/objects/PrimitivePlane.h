#pragma once
#include "Primitive.h"

typedef class PrimitivePlane : public Primitive
{
public:
	PrimitivePlane();

	// PrimitivePlane(float width, float height);

private:
protected:

} Plane;

