#pragma once
#include "Primitive.h"
class PrimitiveCylinder :
	public Primitive
{
};

