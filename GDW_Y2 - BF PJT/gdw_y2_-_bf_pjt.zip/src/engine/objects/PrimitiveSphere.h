#pragma once
#include "Primitive.h"

typedef class PrimitiveSphere : public Primitive
{
public:
	PrimitiveSphere();

private:
protected:
} Sphere;

