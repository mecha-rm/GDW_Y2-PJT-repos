#include "PrimitiveSphere.h"

PrimitiveSphere::PrimitiveSphere() : Primitive()
{
}
