#include "Primitive.h"


typedef class PrimitiveCube : public Primitive
{
public:
	PrimitiveCube();

	// PrimitiveCube(float width, float height);

	// void setWidth();

	// void setHeight(float height);
private:
protected:
} Cube;