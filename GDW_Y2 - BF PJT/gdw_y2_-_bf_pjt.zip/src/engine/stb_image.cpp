#define STB_IMAGE_IMPLEMENTATION // modifies header to have only relevant source code
#include "stb_image.h"
